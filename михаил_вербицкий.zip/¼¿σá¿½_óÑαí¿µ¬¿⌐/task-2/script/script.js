window.onload = () =>{
  let imgContainer = document.querySelector('.img-container'),
  textContainer = document.querySelector('.text'),
  darkContainer = document.querySelector('.dark-container'),
  closeBtn = document.querySelector('.close-btn'),
  resetBtn = document.querySelector('.reset-btn');

  let arrSorted = []

  let deletedImg = JSON.parse(window.localStorage.getItem("deletedImages"));

  // Получение количества картинок и вівод на єкран
  let getCountOfImg = () =>{
    let countOfImg = 0;
    imgContainer.childNodes.forEach((item) => {
      if (item.nodeType == 1) countOfImg++;
    });
    textContainer.innerHTML = `Количество картинок: ${countOfImg}<br>${getNowDate()}`;
  };
  // Получение текущей даті в формате
  let getNowDate = () =>{
    let date = new Date();

    let dd = date.getDate();
    if (dd < 10) dd = '0' + dd;

    let mm = date.getMonth()+1;
    if (mm < 10) mm = '0'+ mm;

    let hh = date.getHours();
    if (hh < 10) hh = '0'+ hh;

    let min = date.getMinutes();
    if (min < 10) min = '0'+ min;

    return `${dd}.${mm}.${date.getFullYear()} ${hh}:${min}`
  };
  // Создание таблиці из картинок
  let makeImgTable = () =>{
    for (var i = 1; i < 13; i++){
      let test = `photo-${i}`;
      let testFunc = (item) => item.alt == test;
      if (!deletedImg.some(testFunc)) {
        let div = document.createElement("div");
        let img = document.createElement("img");
        let btn = document.createElement("button");

        img.setAttribute("src",`./img/${i}.jpg`);
        img.setAttribute("alt",`photo-${i}`);
        btn.innerHTML = "&#215;";
        div.append(img);
        div.append(btn);
        imgContainer.append(div);
      }
    }
    getCountOfImg();
  };

  makeImgTable()

  // Показ картинки
  imgContainer.addEventListener('click', (e) =>{
    let targ = e.target;
    if(targ.tagName == "IMG"){
      let srcInfo = targ.getAttribute("src");
      console.log(srcInfo);
      let curentImg = document.querySelector('.dark-container img');
      curentImg.setAttribute('src',srcInfo);
      darkContainer.classList.toggle('invis-block');
    }
  });

  closeBtn.addEventListener('click',()=>{
    darkContainer.classList.toggle('invis-block');
  });

  // Удаление картинки
  imgContainer.addEventListener('click', (e) =>{
    let targ = e.target;
    if(targ.tagName == "BUTTON"){
      let image = targ.previousSibling;
      let objImg = {
        "src": image.getAttribute("src"),
        "alt": image.getAttribute("alt")
      }
      deletedImg.push(objImg);
      window.localStorage.deletedImages = JSON.stringify(deletedImg);
      // imgContainer.remove(targ.parentNode);
      targ.parentNode.remove();
      console.log(targ.parentNode);
      getCountOfImg()
    }
  });

  // Кнопка востановления
  resetBtn.addEventListener('click',()=>{
    deletedImg = [];
    window.localStorage.deletedImages = JSON.stringify(deletedImg);
    imgContainer.innerHTML="";
    makeImgTable()
  })
}
