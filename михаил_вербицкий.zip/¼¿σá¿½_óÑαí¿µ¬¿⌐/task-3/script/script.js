window.onload = () => {
  let countrySearch = document.querySelector('.input-country'),
  sendBtn = document.querySelector('.send'),
  resetBtn = document.querySelector('.reset'),
  tableContainer = document.querySelector('.table-container'),
  prevValue = window.localStorage.getItem("prevValue"),
  arrSorted = JSON.parse(window.localStorage.getItem("arrSorted")),
  checkCount = document.querySelector('.check-count'),
  checkCountArr = JSON.parse(window.localStorage.getItem("checkCountArr")),
  checkCountVal = window.localStorage.getItem("checkCountVal");

  if (arrSorted == null) arrSorted = [];
  if (prevValue == null) prevValue = '';
  if (checkCountArr == null) checkCountArr = [];
  if (checkCountVal == null) checkCountVal = '';


  // Создание основы даблицы вменсте с количеством отмеченных чекбоксов
  let createTable = () => {
    tableContainer.innerHTML = '';
    checkCount.innerHTML = `Сохраненных в список - ${checkCountVal}`;
    let table = document.createElement("table"),
    tbody = document.createElement("tbody"),
    thead = document.createElement("thead"),
    tr = document.createElement("tr");
    table.append(thead);
    table.append(tbody);
    thead.append(tr);
    for (let i = 0; i < 5; i++) {
      let th = document.createElement("th");
      switch (i) {
        case 0:
        th.innerHTML = "№"
        break;
        case 1:
        th.innerHTML = "Страна"
        break;
        case 2:
        th.innerHTML = "Название"
        break;
        case 3:
        th.innerHTML = "Ссылки"
        break;
        case 4:
        th.innerHTML = "Сохранить в мой список"
        break;
        default:
      }
      tr.append(th);
    };
    tableContainer.append(table);
  }
  // Полная функция отправки запроса и создание всей таблицы
  let createFullTable = () =>{
    if ((countrySearch.value != '') || prevValue != '') {

      createTable();

      let xhr = new XMLHttpRequest();
      xhr.open("GET", "https://raw.githubusercontent.com/Hipo/university-domains-list/master/world_universities_and_domains.json");
      let arr = [];


      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {

          // DANGER------------------------------------------------------------------------------------------------------------------------------------
          arr = JSON.parse(xhr.responseText);
          if (arrSorted.length == 0 || (prevValue.toLowerCase() != countrySearch.value.toLowerCase())) {
            if (countrySearch.value.toLowerCase() == '') {
              arrSorted = arr.filter(i => i.country.toLowerCase() == prevValue.toLowerCase());
            }
            else {
              arrSorted = arr.filter(i => i.country.toLowerCase() == countrySearch.value.toLowerCase());
              prevValue = countrySearch.value;

            }
            window.localStorage.prevValue = prevValue;
            window.localStorage.arrSorted = JSON.stringify(arrSorted)
          }
          // DANGER------------------------------------------------------------------------------------------------------------------------------------


          // arr = JSON.parse(xhr.responseText);
          // arrSorted = arr.filter(i => i.country.toLowerCase() == countrySearch.value.toLowerCase());

          createBodyTable(arrSorted);
        }
      }
      xhr.send();

    }
  }
  // Создание основного содержимого после AJAX запроса
  let createBodyTable = (arrExemple) =>{
    arrExemple.forEach((item, i) => {
      try {
        let tr1 = document.createElement("tr"),
        td1 = document.createElement("td"),
        td2 = document.createElement("td"),
        td3 = document.createElement("td"),
        td4 = document.createElement("td"),
        td5 = document.createElement("td");

        td1.innerHTML = i+1;
        td2.innerHTML = item.country;
        td3.innerHTML = item.name;
        td4.innerHTML = '';
        for (let i = 0; i < item["web_pages"].length; i++) {
          td4.innerHTML = td4.innerHTML + `<a href="${item["web_pages"][i]}">${item["web_pages"][i]}</a><br>`;
        }
        td5.innerHTML = `<input type="checkbox" name="${i}" value="${i}">`;

        document.querySelector('tbody').append(tr1);
        tr1.append(td1);
        tr1.append(td2);
        tr1.append(td3);
        tr1.append(td4);
        tr1.append(td5);

      } catch (e) {
        console.log(e);
      }
    });

    findChecked();
  }
  // Очистка таблицы
  let clearTable = () => {
    tableContainer.innerHTML = '';
    prevValue = '';
    arrSorted = [];
    checkCountArr = [];
    checkCountVal=0;
    checkCount.innerHTML = `Сохраненных в список - 0`;
    window.localStorage.prevValue = '';
    window.localStorage.arrSorted = JSON.stringify(arrSorted);
    window.localStorage.checkCountArr = JSON.stringify(checkCountArr);
    window.localStorage.checkCountVal = JSON.stringify(checkCountVal);
  }
  // Найти соответсвие между создаными чекбоксами и отмечеными в локальном хранилище
  let findChecked = () => {
    let allCheckbox = document.querySelectorAll('tbody td input');
    console.log(allCheckbox);
    allCheckbox.forEach((item) => {
      if (checkCountArr.indexOf(""+item.value) >= 0) {
        item.checked = true;
      }
    });
  }
  // Проверка есть ли в хранилище информация с заполненным масивом
  if (arrSorted.length != 0) {
    createFullTable();
  }


  sendBtn.addEventListener('click', createFullTable);
  resetBtn.addEventListener('click', clearTable);
  tableContainer.addEventListener('click', (e) => {
    let targ = e.target;

    if (targ.tagName == 'INPUT') {
      if (targ.checked) {
        checkCountVal++
        checkCountArr.push(targ.value);

        window.localStorage.checkCountArr = JSON.stringify(checkCountArr);
        window.localStorage.checkCountVal = JSON.stringify(checkCountVal);

        checkCount.innerHTML = `Сохраненных в список - ${checkCountVal}`
      } else {
        checkCountVal--;
        if (checkCountVal<0) {
          checkCountVal = 0
        }
        let checkIndex = checkCountArr.indexOf(targ.value);
        checkCountArr.splice(checkIndex,1);

        window.localStorage.checkCountArr = JSON.stringify(checkCountArr);
        window.localStorage.checkCountVal = JSON.stringify(checkCountVal);

        checkCount.innerHTML = `Сохраненных в список - ${checkCountVal}`
      }
    }
  });
}
